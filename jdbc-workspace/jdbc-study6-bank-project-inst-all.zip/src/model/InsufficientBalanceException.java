package model;

public class InsufficientBalanceException extends Exception {
	private static final long serialVersionUID = 2046794047983657245L;

	public InsufficientBalanceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
