package model;

public class NoMoneyException extends Exception {
	private static final long serialVersionUID = -4236638528117552246L;

	public NoMoneyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
