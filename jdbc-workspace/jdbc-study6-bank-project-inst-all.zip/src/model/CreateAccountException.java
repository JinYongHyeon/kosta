package model;

public class CreateAccountException extends Exception{
	private static final long serialVersionUID = 491332526990042396L;

	public CreateAccountException(String message){
		super(message);
	}
}
