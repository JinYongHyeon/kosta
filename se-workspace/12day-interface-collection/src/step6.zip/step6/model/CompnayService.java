package step6.model;

public class CompnayService {

	private Employee[] ep;
	private Employee employee;
	private int index;
	private int point;

	public CompnayService(int length) {
		ep = new Employee[length];
	}

	public void add(Employee e) {
		ep[index++] = e;
	}

	public void printAll() {
		for (int i = 0; i < index; i++) {
			System.out.println(ep[i]);
		}
	}

	public Employee findById(String empId) {
		for (int i = 0; i < index; i++) {
			if (empId.equals(ep[i].getEmpId())) {
				employee = ep[i];
			}
		}
		return employee;
	}

	public void removeById(String empId) {

		for (int i = 0; i < index; i++) {

			if (empId.equals(ep[i].getEmpId())) {
				point = i;
				ep[i] = ep[++point];
				for (int j = point; j < index; j++) {
					++point;
					if (point < index) {

						ep[j] = ep[point];

					}

				}
			}

			if (i == index - 1) {
				ep[i] = null;
			}
		}

	}

}
